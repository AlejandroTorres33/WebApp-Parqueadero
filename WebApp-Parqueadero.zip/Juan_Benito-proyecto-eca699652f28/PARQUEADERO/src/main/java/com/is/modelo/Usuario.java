/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.is.modelo;

/**
 *
 * @author Richard Bejarano
 */
public class Usuario {
    String identificacion;
    String nombre;
    String apellido;
    String tipo;
    String correo;
    String contraseña;
    String celular;

    public Usuario(String identificacion, String nombre, String apellido, String tipo, String correo, String contraseña, String celular) {
        this.identificacion = identificacion;
        this.nombre = nombre;
        this.apellido = apellido;
        this.tipo = tipo;
        this.correo = correo;
        this.contraseña = contraseña;
        this.celular = celular;
    }
    

    public String getIdentificacion() {
        return identificacion;
    }

    public void setIdentificacion(String identificacion) {
        this.identificacion = identificacion;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    public String getCelular() {
        return celular;
    }

    public void setCelular(String celular) {
        this.celular = celular;
    }
    
    
    
    
    
}
