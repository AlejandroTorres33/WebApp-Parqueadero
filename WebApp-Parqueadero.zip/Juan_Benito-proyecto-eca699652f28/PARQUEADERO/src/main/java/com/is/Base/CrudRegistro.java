/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.is.Base;

import com.is.modelo.Parqueadero;
import com.is.modelo.Registro;
import com.is.modelo.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author FELIPE
 */
public class CrudRegistro {
    Registro p;

    public boolean insertarR(Registro re) throws SQLException {
        int res = 0;
        Connection conne = BaseDatos.getConecction();
        PreparedStatement pstatement = null;
        ResultSet resultSet = null;
        String sql = "";
        sql = "INSERT INTO `parqueadero`.`registro` (`placa`, `fechaInico`, `HoraInicio`, `fechaFinal`, `horaFinal`, `PrecioTotal`, `codigo`, `coor`) VALUES ('";
        sql = sql + re.getPlaca() + "',";
        sql = sql + "'" + re.getF_ini() + "',";
        sql = sql + "'" + re.getH_ini() + "',";
        sql = sql + "'" + re.getF_fin() + "',";
        sql = sql + "'" + re.getH_fin() + "',";
        sql = sql + "'" + re.getPrecio() + "',";
        sql = sql + "'" + re.getCod() + "',";
        sql = sql + "'" + re.getCoor() + "'";
        sql = sql + ")";
        System.out.println("sql=" + sql);
        pstatement = conne.prepareStatement(sql);
        res = pstatement.executeUpdate();
        try {
            if (res == 1) {
                conne.commit();
                return true;
            } else {
                System.out.println("Error al insertar...");
                conne.rollback();
                return false;
            }
        } catch (SQLException ex) {
            conne.rollback();
            Logger.getLogger(Usuario.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    public ArrayList<Registro> consultaRegistros() {

        PreparedStatement pstatement = null;
        ResultSet resultSet = null;
        String sql = " SELECT * ";
        sql = sql + " FROM registro ";

        ArrayList<Registro> listado = new ArrayList<Registro>();
        try {
            Connection conne = BaseDatos.getConecction();
            pstatement = conne.prepareStatement(sql);
            resultSet = pstatement.executeQuery();
            while (resultSet.next()) {
                Registro r = new Registro();
                r.setPlaca(resultSet.getString(1));
                r.setF_ini(resultSet.getString(2));
                r.setH_ini(resultSet.getString(3));
                r.setF_fin(resultSet.getString(4));
                r.setH_fin(resultSet.getString(5));
                r.setPrecio(resultSet.getString(6));
                r.setCod(resultSet.getString(7));
                r.setCoor(resultSet.getString(8));
                
                listado.add(r);
            }
        } catch (SQLException ex) {
            Logger.getLogger(Usuario.class.getName()).log(Level.SEVERE, null, ex);
        }
        return listado;
    }
}
