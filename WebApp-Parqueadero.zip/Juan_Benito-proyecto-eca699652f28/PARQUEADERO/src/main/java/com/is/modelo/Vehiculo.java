/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.is.modelo;

/**
 *
 * @author alejo
 */
public class Vehiculo {
    String plana;
    String tipo;
    String identificacionUsuario;

    public Vehiculo() {
    }

    public String getPlana() {
        return plana;
    }

    public void setPlana(String plana) {
        this.plana = plana;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getIdentificacionUsuario() {
        return identificacionUsuario;
    }

    public void setIdentificacionUsuario(String identificacionUsuario) {
        this.identificacionUsuario = identificacionUsuario;
    }
    
}
