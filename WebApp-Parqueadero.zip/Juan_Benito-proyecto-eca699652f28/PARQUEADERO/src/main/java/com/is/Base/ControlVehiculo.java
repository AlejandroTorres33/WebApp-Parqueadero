/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.is.Base;

import com.is.modelo.Vehiculo;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author alejo
 */
public class ControlVehiculo extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            String pla = request.getParameter("pla");
            String F_in = request.getParameter("f_in");
            String H_in = request.getParameter("h_in");
            String F_fi = request.getParameter("f_fi");
            String H_fi = request.getParameter("h_fi");
            String Precio = request.getParameter("precio");
            String codi = request.getParameter("codi");
            String coor = request.getParameter("coor");

            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet ControlMatriz</title>");
            out.println("<script type='text/javascript'>alert('Auto insertado exitosamente');location.href='ControlRegistro?pla="+pla+"&f_in="+F_in+""
                    + "&h_in="+H_in+"&f_fi="+F_fi+"&h_fi="+H_fi+"&precio="+Precio+"&codi="+codi+"&coor="+coor+"'</script>");
            out.println("</head>");
            out.println("<body>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String pla = request.getParameter("pla");
        String tip = request.getParameter("tip");
        String idu = request.getParameter("idu");

        Vehiculo v = new Vehiculo();

        v.setPlana(pla);
        v.setTipo(tip);
        v.setIdentificacionUsuario(idu);

        CrudVehiculo crudV = new CrudVehiculo();
        try {
            crudV.insertarV(v);
        } catch (SQLException ex) {
            Logger.getLogger(ControladorRegistar.class.getName()).log(Level.SEVERE, null, ex);
        }

        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
