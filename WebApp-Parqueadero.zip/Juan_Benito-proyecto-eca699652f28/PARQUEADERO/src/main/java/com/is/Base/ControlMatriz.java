/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.is.Base;

import com.is.modelo.Parqueadero;
import com.is.modelo.Usuario;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author FELIPE
 */
public class ControlMatriz extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            
            //Por si se quiere guardar el parqueadero en un arrray de 3 dimensiones
            
            int x = Integer.parseInt(request.getParameter("x"));
            int y = Integer.parseInt(request.getParameter("y"));
            int np = Integer.parseInt(request.getParameter("np"));
            int aux = 0;
            
            
            
            String[] sep = request.getParameter("matriz").split(",");
            String[][][] matriz_p = armar_m(np,y,x,sep);
            
            
            
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet ControlMatriz</title>");
            out.println("<script type='text/javascript'>location.href='PRINCIPAL.jsp';</script>");
            out.println("</head>");
            out.println("<body>");
            out.println("</body>");
            out.println("</html>");
        }
    }
    
    private String[][][] armar_m (int a, int b, int c, String[] d){
        String[][][] matriz_p = new String [a][b][c];
        int aux=0;
        for (int i = 0; i < a; i++) {
            for (int j = 0; j < b; j++) {
                for (int k = 0; k < c; k++) {
                    matriz_p[i][j][k]=d[aux];
                    aux++;
                }
            }
        }
        return matriz_p;
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String codigo = request.getParameter("cod");
        String c_car = request.getParameter("c_c");
        String c_mo = request.getParameter("c_m");
        String c_bi = request.getParameter("c_b");
        String tipo = request.getParameter("ti");
        String n_pisos = request.getParameter("np");
        String tar = request.getParameter("ta");
        String matriz = request.getParameter("matriz");
        String nomb = request.getParameter("nomb");
        String hor = request.getParameter("hor");
        String c_x = request.getParameter("x");
        String c_y = request.getParameter("y");
        
        
        Parqueadero p = new Parqueadero();
        
        p.setCodigo(codigo);
        p.setC_carros(c_car);
        p.setC_motos(c_mo);
        p.setC_bici(c_bi);
        p.setTipo(tipo);
        p.setN_pisos(n_pisos);
        p.setTarifa(tar);
        p.setMatriz(matriz);
        p.setNombre(nomb);
        p.setHorario(hor);
        p.setX(c_x);
        p.setY(c_y);
        
        CrudParqueadero crudP = new CrudParqueadero();
        try {
            crudP.insertarP(p);
        } catch (SQLException ex) {
            Logger.getLogger(ControladorRegistar.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
