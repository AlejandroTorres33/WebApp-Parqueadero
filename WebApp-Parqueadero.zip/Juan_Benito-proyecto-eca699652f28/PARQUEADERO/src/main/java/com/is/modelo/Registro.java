/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.is.modelo;

/**
 *
 * @author FELIPE
 */
public class Registro {
    String placa;
    String F_ini;
    String H_ini;
    String F_fin;
    String H_fin;
    String Precio;
    String cod;
    String coor;

    public Registro() {
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public String getF_ini() {
        return F_ini;
    }

    public void setF_ini(String F_ini) {
        this.F_ini = F_ini;
    }

    public String getH_ini() {
        return H_ini;
    }

    public void setH_ini(String H_ini) {
        this.H_ini = H_ini;
    }

    public String getF_fin() {
        return F_fin;
    }

    public void setF_fin(String F_fin) {
        this.F_fin = F_fin;
    }

    public String getH_fin() {
        return H_fin;
    }

    public void setH_fin(String H_fin) {
        this.H_fin = H_fin;
    }

    public String getPrecio() {
        return Precio;
    }

    public void setPrecio(String Precio) {
        this.Precio = Precio;
    }

    public String getCod() {
        return cod;
    }

    public void setCod(String cod) {
        this.cod = cod;
    }

    public String getCoor() {
        return coor;
    }

    public void setCoor(String coor) {
        this.coor = coor;
    }
    
    
}
