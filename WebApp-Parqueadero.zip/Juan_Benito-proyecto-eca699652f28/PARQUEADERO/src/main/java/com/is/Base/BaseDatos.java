/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.is.Base;

import com.is.modelo.Usuario;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class BaseDatos {

    private static Connection connection = null;

    public static Connection getConecction() throws SQLException {
        String ip = "localhost";
        String basedatos = "parqueadero";
        String usuario = "root";
        String pass = "root";
        String puerto = "3306";
        String url = "jdbc:mysql://" + ip + ":" + puerto + "/" + basedatos + "?serverTimezone=UTC&autoReconnect=true&useSSL=false";
        try {
            if (BaseDatos.connection == null) {
                Class.forName("com.mysql.cj.jdbc.Driver");
                BaseDatos.connection = DriverManager.getConnection(url, usuario, pass);
                BaseDatos.connection.setAutoCommit(false);
                return BaseDatos.connection;
            }
        } catch (Exception ex) {
            System.out.println("ERROR EN EL DRIVER \n ERROR :" + ex.getMessage());
            Logger.getLogger(BaseDatos.class.getName()).log(Level.SEVERE, null, ex);
            BaseDatos.connection.close();
        }
        return BaseDatos.connection;
    }
    
    
     public ArrayList<Usuario> consultaUsuario(String identificacion){
    
        PreparedStatement pstatement=null;
        ResultSet resultSet=null;
        String sql=" SELECT * ";
        sql=sql + " FROM usuario ";
        sql=sql + "  where identificacion='"+identificacion+"'";
        
       ArrayList<Usuario> listado= new ArrayList<Usuario>();
        try {
            Connection conne=BaseDatos.getConecction();
            pstatement= conne.prepareStatement(sql);
            resultSet = pstatement.executeQuery();
            while (resultSet.next()) {
              Usuario u=new Usuario(resultSet.getString(1), resultSet.getString(2),resultSet.getString(3),resultSet.getString(4),resultSet.getString(5),resultSet.getString(6),resultSet.getString(7));              

              listado.add(u);
            }
        } catch (SQLException ex) {
            Logger.getLogger(Usuario.class.getName()).log(Level.SEVERE,null,ex);
        }
        return listado;
    }
     
          public ArrayList<Usuario> validarUsuario(String identificacion,String contra){
    
        PreparedStatement pstatement=null;
        ResultSet resultSet=null;
        String sql=" SELECT * ";
        sql=sql + " FROM usuario ";
        sql=sql + "  where identificacion='"+identificacion+"'";
        sql=sql +"AND contrasena='"+contra+"'";
        
       ArrayList<Usuario> listado= new ArrayList<Usuario>();
        try {
            Connection conne=BaseDatos.getConecction();
            pstatement= conne.prepareStatement(sql);
            resultSet = pstatement.executeQuery();
            while (resultSet.next()) {
              Usuario u=new Usuario(resultSet.getString(1), resultSet.getString(2),resultSet.getString(3),resultSet.getString(4),resultSet.getString(5),resultSet.getString(6),resultSet.getString(7));              

              listado.add(u);
            }
        } catch (SQLException ex) {
            Logger.getLogger(Usuario.class.getName()).log(Level.SEVERE,null,ex);
        }
        return listado;
    }
}
