/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.is.Base;

import com.is.modelo.Parqueadero;
import java.util.ArrayList;

/**
 *
 * @author Richard Bejarano
 */
public class pruebas {
    public static void main(String[] rhbp){
    
    CrudParqueadero p=new CrudParqueadero();
    ArrayList<Parqueadero> listado = new ArrayList<Parqueadero>();
    listado=p.consultaParqueaderos();
    for(int i=0;i<listado.size();i++){
        System.out.println(listado.get(i).getCodigo());
    
    }
    
    }
    
}
