/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.is.modelo;

/**
 *
 * @author Richard Bejarano
 */
public class Parqueadero {
    String codigo;
    String nombre;
    String direccion;
    String tarifa;
    String tipo;
    String n_pisos;
    String horario;
    String x;
    String y;

    public String getX() {
        return x;
    }

    public void setX(String x) {
        this.x = x;
    }

    public String getY() {
        return y;
    }

    public void setY(String y) {
        this.y = y;
    }

    public String getHorario() {
        return horario;
    }

    public void setHorario(String horario) {
        this.horario = horario;
    }
    String c_carros;
    String c_motos;
    String c_bici;
    String matriz;

    public String getP_carros() {
        return p_carros;
    }

    public void setP_carros(String p_carros) {
        this.p_carros = p_carros;
    }

    public String getP_motos() {
        return p_motos;
    }

    public void setP_motos(String p_motos) {
        this.p_motos = p_motos;
    }

    public String getB_bici() {
        return b_bici;
    }

    public void setB_bici(String b_bici) {
        this.b_bici = b_bici;
    }
    String p_carros;
    String p_motos;
    String b_bici;



    public String getMatriz() {
        return matriz;
    }

    public void setMatriz(String matriz) {
        this.matriz = matriz;
    }

    public Parqueadero() {
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getTarifa() {
        return tarifa;
    }

    public void setTarifa(String tarifa) {
        this.tarifa = tarifa;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getN_pisos() {
        return n_pisos;
    }

    public void setN_pisos(String n_pisos) {
        this.n_pisos = n_pisos;
    }

    public String getC_carros() {
        return c_carros;
    }

    public void setC_carros(String c_carros) {
        this.c_carros = c_carros;
    }

    public String getC_motos() {
        return c_motos;
    }

    public void setC_motos(String c_motos) {
        this.c_motos = c_motos;
    }

    public String getC_bici() {
        return c_bici;
    }

    public void setC_bici(String c_bici) {
        this.c_bici = c_bici;
    }
    
    
}
