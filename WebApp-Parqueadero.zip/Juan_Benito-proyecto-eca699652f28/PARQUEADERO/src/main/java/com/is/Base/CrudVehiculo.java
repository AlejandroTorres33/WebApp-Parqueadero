package com.is.Base;

import com.is.modelo.Parqueadero;
import com.is.modelo.Registro;
import com.is.modelo.Usuario;
import com.is.modelo.Vehiculo;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class CrudVehiculo {

    Vehiculo p;
    public boolean insertarV(Vehiculo re) throws SQLException {
        int res = 0;
        Connection conne = BaseDatos.getConecction();
        PreparedStatement pstatement = null;
        ResultSet resultSet = null;
        String sql = "";
        sql = "INSERT INTO `parqueadero`.`vehiculo` (`plana`, `tipo`, `identificacionUsuario`) VALUES ('";
        sql = sql + re.getPlana() + "',";
        sql = sql + "'" + re.getTipo()+ "',";
        sql = sql + "'" + re.getIdentificacionUsuario()+"'";
        sql = sql + ")";
        System.out.println("sql=" + sql);
        pstatement = conne.prepareStatement(sql);
        res = pstatement.executeUpdate();
        try {
            if (res == 1) {
                conne.commit();
                return true;
            } else {
                System.out.println("Error al insertar...");
                conne.rollback();
                return false;
            }
        } catch (SQLException ex) {
            conne.rollback();
            Logger.getLogger(Usuario.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
}
