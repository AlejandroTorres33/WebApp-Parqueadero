/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.is.Base;

import com.is.modelo.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;


public class CrudUsuario {
        Usuario u;
    
        public boolean insertaruser(Usuario persona) throws SQLException {
        int res = 0;
        Connection conne = BaseDatos.getConecction();
        PreparedStatement pstatement = null;
        ResultSet resultSet = null;
        String sql = "";
        sql = "insert into usuario (identificacion,nombre,apellido,tipo,email,contrasena,celular) VALUES ('";
        sql = sql + persona.getIdentificacion() + "',";
        sql = sql + "'" + persona.getNombre() + "',";
        sql = sql + "'" + persona.getApellido() + "',";
        sql = sql + "'" + persona.getTipo() + "',";
        sql = sql + "'" + persona.getCorreo() + "',";
        sql = sql + "'" + persona.getContraseña() + "',";
        sql = sql + "'" + persona.getCelular() + "'";
        sql = sql + ")";
        System.out.println("sql=" + sql);
        pstatement = conne.prepareStatement(sql);
        res = pstatement.executeUpdate();
        try {
            if (res == 1) {
                conne.commit();
                return true;
            } else {
                System.out.println("Error al insertar...");
                conne.rollback();
                return false;
            }
        } catch (SQLException ex) {
            conne.rollback();
            Logger.getLogger(Usuario.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
}
