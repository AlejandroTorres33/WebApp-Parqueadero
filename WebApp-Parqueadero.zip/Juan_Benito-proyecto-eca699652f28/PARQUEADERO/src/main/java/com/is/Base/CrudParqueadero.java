/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.is.Base;

import com.is.modelo.Parqueadero;
import com.is.modelo.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author FELIPE
 */
public class CrudParqueadero {

    Parqueadero p;

    public boolean insertarP(Parqueadero per) throws SQLException {
        int res = 0;
        Connection conne = BaseDatos.getConecction();
        PreparedStatement pstatement = null;
        ResultSet resultSet = null;
        String sql = "";
        sql = "INSERT INTO `parqueadero`.`parqueadero` (`codigo`, `capacidadC`, `capacidadM`, `capacidadB`, `tipo`, `pisos`, `precioC`, `precioM`, `preciob`, `matriz`, `nombre`, `horario`, `x`, `y`) VALUES ('";
        sql = sql + per.getCodigo() + "',";
        sql = sql + "'" + per.getC_carros() + "',";
        sql = sql + "'" + per.getC_motos() + "',";
        sql = sql + "'" + per.getC_bici() + "',";
        sql = sql + "'" + per.getTipo() + "',";
        sql = sql + "'" + per.getN_pisos() + "',";
        sql = sql + "'" + per.getTarifa() + "',";
        sql = sql + "'" + per.getTarifa() + "',";
        sql = sql + "'" + per.getTarifa() + "',";
        sql = sql + "'" + per.getMatriz() + "',";
        sql = sql + "'" + per.getNombre() + "',";
        sql = sql + "'" + per.getHorario() + "',";
        sql = sql + "'" + per.getX() + "',";
        sql = sql + "'" + per.getY() + "'";
        sql = sql + ")";
        System.out.println("sql=" + sql);
        pstatement = conne.prepareStatement(sql);
        res = pstatement.executeUpdate();
        try {
            if (res == 1) {
                conne.commit();
                return true;
            } else {
                System.out.println("Error al insertar...");
                conne.rollback();
                return false;
            }
        } catch (SQLException ex) {
            conne.rollback();
            Logger.getLogger(Usuario.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    public ArrayList<Parqueadero> consultaParqueaderos() {

        PreparedStatement pstatement = null;
        ResultSet resultSet = null;
        String sql = " SELECT * ";
        sql = sql + " FROM parqueadero ";

        ArrayList<Parqueadero> listado = new ArrayList<Parqueadero>();
        try {
            Connection conne = BaseDatos.getConecction();
            pstatement = conne.prepareStatement(sql);
            resultSet = pstatement.executeQuery();
            while (resultSet.next()) {
                Parqueadero p = new Parqueadero();
                p.setCodigo(resultSet.getString(1));
                p.setC_carros(resultSet.getString(2));
                p.setC_motos(resultSet.getString(3));
                p.setC_bici(resultSet.getString(4));
                p.setTipo(resultSet.getString(5));
                p.setN_pisos(resultSet.getString(6));
                p.setP_carros(resultSet.getString(7));
                p.setP_motos(resultSet.getString(8));
                p.setB_bici(resultSet.getString(9));

                p.setMatriz(resultSet.getString(11));
                p.setNombre(resultSet.getString(12));
                p.setHorario(resultSet.getString(13));
                p.setX(resultSet.getString(14));
                p.setY(resultSet.getString(15));
                listado.add(p);
            }
        } catch (SQLException ex) {
            Logger.getLogger(Usuario.class.getName()).log(Level.SEVERE, null, ex);
        }
        return listado;
    }

    public boolean eliminarparqueadero(String Codigo) throws SQLException {

        int res = 0;
        Connection conne = BaseDatos.getConecction();
        PreparedStatement pstatement = null;
        ResultSet resultSet = null;
        String sql = "DELETE FROM `parqueadero`.`parqueadero` WHERE (`codigo` = '" + Codigo + "');";
        System.out.println("sql=" + sql);
        pstatement = conne.prepareStatement(sql);

        res = pstatement.executeUpdate();
        try {
            if (res == 1) {
                conne.commit();
                return true;
            } else {
                System.out.println("Error al eliminar...");
                conne.rollback();
                return false;
            }
        } catch (SQLException ex) {
            conne.rollback();
            Logger.getLogger(Usuario.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
}
