
import com.is.Base.BaseDatos;
import com.is.Base.CrudUsuario;
import com.is.modelo.Usuario;
import java.sql.SQLException;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Richard Bejarano
 */
public class prueba {
    
            public static void main(String[] args) throws SQLException{
            BaseDatos b=new BaseDatos();    
            Usuario u =new Usuario("1007599146","nando","bejarano","usuario","gmail","pas","350");
            CrudUsuario in = new CrudUsuario();
                boolean insertaruser = in.insertaruser(u);
            }
    
}
